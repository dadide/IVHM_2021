cd ../input
rm -r *
cd ../result
rm -r *
cd ../speed
rm -r *
cd ../log
rm -r *
cd ../abnormity
rm -r *
