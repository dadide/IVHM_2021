#!/bin/bash
python3 move2Onedrive.py
